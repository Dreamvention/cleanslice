import { IUser, IUserData } from './user.types';
export declare class User implements IUser {
    readonly id: number;
    readonly name: string;
    readonly email: string;
    readonly password: string;
    readonly createdAt: Date;
    readonly updatedAt: Date;
    constructor(data: IUserData);
    validate(): void;
}
