"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.IamLambda = void 0;
const data_aws_iam_policy_document_1 = require("@cdktf/provider-aws/lib/data-aws-iam-policy-document");
const iam_policy_1 = require("@cdktf/provider-aws/lib/iam-policy");
const iam_role_1 = require("@cdktf/provider-aws/lib/iam-role");
const config_1 = require("./config");
class IamLambda {
    static init(scope) {
        const assumeRole = new data_aws_iam_policy_document_1.DataAwsIamPolicyDocument(scope, 'assume_role', {
            statement: [
                {
                    effect: 'Allow',
                    principals: [
                        {
                            type: 'Service',
                            identifiers: ['lambda.amazonaws.com'],
                        },
                    ],
                    actions: ['sts:AssumeRole'],
                },
            ],
        });
        const lambdaPolicy = new data_aws_iam_policy_document_1.DataAwsIamPolicyDocument(scope, 'lambda-policy', {
            statement: [
                {
                    effect: 'Allow',
                    actions: ['s3:*'],
                    resources: ['*'],
                },
                {
                    effect: 'Allow',
                    actions: [
                        'ec2:DescribeNetworkInterfaces',
                        'ec2:CreateNetworkInterface',
                        'ec2:DeleteNetworkInterface',
                        'ec2:DescribeInstances',
                        'ec2:AttachNetworkInterface',
                    ],
                    resources: ['*'],
                },
                {
                    effect: 'Allow',
                    actions: ['cognito-idp:*'],
                    resources: ['*'],
                },
                {
                    effect: 'Allow',
                    actions: ['lambda:*'],
                    resources: ['*'],
                },
                {
                    effect: 'Allow',
                    actions: [
                        'dynamodb:DescribeTable',
                        'dynamodb:Query',
                        'dynamodb:Scan',
                        'dynamodb:GetItem',
                        'dynamodb:PutItem',
                        'dynamodb:UpdateItem',
                        'dynamodb:DeleteItem',
                        'dynamodb:CreateTable',
                    ],
                    resources: ['*'],
                },
                {
                    effect: 'Allow',
                    actions: ['rds:*', 's3:*'],
                    resources: ['arn:aws:rds:*:*:db:*', 'arn:aws:rds:*:*:cluster:*', 'arn:aws:rds-db:*:*:dbuser:*/*'],
                },
            ],
        });
        const iamLambdaPolicy = new iam_policy_1.IamPolicy(scope, 'iam-lambda-policy', {
            name: `${process.env.npm_package_name}-${config_1.default.env}-iam-lambda-policy`,
            path: '/',
            policy: lambdaPolicy.json,
        });
        const iamForLambda = new iam_role_1.IamRole(scope, 'iam-for-lambda', {
            name: `${process.env.npm_package_name}-${config_1.default.env}-function-role`,
            assumeRolePolicy: assumeRole.json,
            managedPolicyArns: ['arn:aws:iam::aws:policy/service-role/AWSLambdaBasicExecutionRole', iamLambdaPolicy.arn],
        });
        return {
            iamForLambda,
        };
    }
}
exports.IamLambda = IamLambda;
//# sourceMappingURL=iam.terraform.js.map