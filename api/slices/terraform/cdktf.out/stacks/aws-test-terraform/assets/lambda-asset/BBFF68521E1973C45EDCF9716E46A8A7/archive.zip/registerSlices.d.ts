import { DynamicModule } from '@nestjs/common';
export declare class SlicesModule {
    static registerAsync(): Promise<DynamicModule>;
}
