"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Lambda = void 0;
const config_1 = require("./config");
const lambda_function_1 = require("@cdktf/provider-aws/lib/lambda-function");
const s3_bucket_1 = require("@cdktf/provider-aws/lib/s3-bucket");
const s3_bucket_object_1 = require("@cdktf/provider-aws/lib/s3-bucket-object");
const cdktf_1 = require("cdktf");
const path = require("path");
class Lambda {
    static init(scope, role) {
        const bucket = new s3_bucket_1.S3Bucket(scope, 'bucket', {
            bucketPrefix: `${process.env.npm_package_name}-${config_1.default.env}-lambda-arhive`,
        });
        const asset = new cdktf_1.TerraformAsset(scope, 'lambda-asset', {
            path: path.resolve(__dirname, '../../dist'),
            type: cdktf_1.AssetType.ARCHIVE,
        });
        const lambdaArchive = new s3_bucket_object_1.S3BucketObject(scope, 'lambda-archive', {
            bucket: bucket.bucket,
            key: `${asset.fileName}`,
            source: asset.path,
        });
        const lambdaMain = new lambda_function_1.LambdaFunction(scope, 'lambda', {
            runtime: 'nodejs18.x',
            s3Bucket: bucket.bucket,
            s3Key: lambdaArchive.key,
            handler: 'dist/src/lambda.handler',
            functionName: `${process.env.npm_package_name}-${config_1.default.env}-function-main`,
            role: role.arn,
            environment: {
                variables: {
                    DATABASE_URL: 'file:./dev.db',
                },
            },
        });
        return {
            lambdaMain,
        };
    }
}
exports.Lambda = Lambda;
//# sourceMappingURL=functions.terraform.js.map