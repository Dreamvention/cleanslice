declare const _default: {
    project: string;
    env: string;
    region: string;
    profile: string;
    imageUrl: string;
    cognitoUrl: string;
    apiUrl: string;
    appUrl: string;
    VPC_CIDR: number;
    DB_NAME: string;
    DB_USERNAME: string;
    google: {
        client_id: string;
        client_secret: string;
    };
    userPoolCallbacks: string[];
    userPoolLogoutURLs: string[];
    branchName: string;
    slsStage: string;
};
export default _default;
