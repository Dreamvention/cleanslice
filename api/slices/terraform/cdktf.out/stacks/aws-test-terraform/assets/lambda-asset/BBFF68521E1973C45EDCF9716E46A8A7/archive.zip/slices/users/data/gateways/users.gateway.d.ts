import { PrismaService } from 'src/prisma/prisma.service';
import { IUserData } from '../../domain/entities';
import { IUsersGateway } from '../../domain/gateways';
import { UserMapper } from '../mappers';
export declare class UsersGateway implements IUsersGateway {
    private prisma;
    private map;
    constructor(prisma: PrismaService, map: UserMapper);
    getUsers(): Promise<IUserData[]>;
    getUser(id: number): Promise<IUserData>;
    createUser(data: IUserData): Promise<IUserData>;
    updateUser(id: number, data: IUserData): Promise<IUserData>;
    deleteUser(id: number): Promise<boolean>;
}
