"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.IUsersGateway = void 0;
class IUsersGateway {
}
exports.IUsersGateway = IUsersGateway;
//# sourceMappingURL=users.gateway.js.map