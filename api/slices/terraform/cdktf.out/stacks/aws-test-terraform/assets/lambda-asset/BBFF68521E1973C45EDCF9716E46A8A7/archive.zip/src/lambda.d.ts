import 'reflect-metadata';
export declare const handler: any;
