import { IUserData } from '../domain/entities';
export declare class CreateUserDto implements IUserData {
    name: string;
    email: string;
    password: string;
}
