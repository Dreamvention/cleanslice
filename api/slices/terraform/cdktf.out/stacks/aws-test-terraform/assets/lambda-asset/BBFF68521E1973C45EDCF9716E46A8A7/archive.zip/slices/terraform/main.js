"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const cdktf_1 = require("cdktf");
const provider_1 = require("@cdktf/provider-aws/lib/provider");
const iam_terraform_1 = require("./iam.terraform");
const functions_terraform_1 = require("./functions.terraform");
class MyStack extends cdktf_1.TerraformStack {
    constructor(scope, id) {
        super(scope, id);
        new provider_1.AwsProvider(this, 'AWS', {
            region: 'us-east-1',
        });
        const { iamForLambda } = iam_terraform_1.IamLambda.init(this);
        const { lambdaMain } = functions_terraform_1.Lambda.init(this, iamForLambda);
        new cdktf_1.TerraformOutput(this, 'lambda_arn', {
            value: lambdaMain.arn,
        });
    }
}
const app = new cdktf_1.App();
new MyStack(app, 'aws-test-terraform');
app.synth();
//# sourceMappingURL=main.js.map