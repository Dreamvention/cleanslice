import { IUserData } from '../domain/entities';
export declare class UpdateUserDto implements IUserData {
    name: string;
    email: string;
    password: string;
}
