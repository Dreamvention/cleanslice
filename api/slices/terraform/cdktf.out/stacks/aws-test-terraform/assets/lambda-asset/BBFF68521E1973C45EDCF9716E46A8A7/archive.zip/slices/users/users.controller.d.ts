import { IUsersGateway } from './domain/gateways';
import { IUserData } from './domain/entities';
import { CreateUserDto, UpdateUserDto } from './dtos';
export declare class UsersController {
    private usersGateway;
    constructor(usersGateway: IUsersGateway);
    getUsers(): Promise<IUserData[]>;
    getUser(id: string): Promise<IUserData>;
    createUser(data: CreateUserDto): Promise<IUserData>;
    updateUser(id: string, data: UpdateUserDto): Promise<IUserData>;
    deleteUser(id: string): Promise<boolean>;
}
