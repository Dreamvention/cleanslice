import { IUserData } from '../domain/entities';
export declare class UserDto implements IUserData {
    id: number;
    name: string;
    email: string;
    createdAt: Date;
    updatedAt: Date;
}
