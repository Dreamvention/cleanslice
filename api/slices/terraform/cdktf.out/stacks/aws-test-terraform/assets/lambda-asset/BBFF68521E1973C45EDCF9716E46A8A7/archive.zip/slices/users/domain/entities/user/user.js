"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.User = void 0;
class User {
    constructor(data) {
        Object.assign(this, data);
    }
    validate() {
        throw new Error('Method not implemented.');
    }
}
exports.User = User;
//# sourceMappingURL=user.js.map