import { Construct } from 'constructs';
import { IamRole } from '@cdktf/provider-aws/lib/iam-role';
import { LambdaFunction } from '@cdktf/provider-aws/lib/lambda-function';
export declare class Lambda {
    static init(scope: Construct, role: IamRole): {
        lambdaMain: LambdaFunction;
    };
}
