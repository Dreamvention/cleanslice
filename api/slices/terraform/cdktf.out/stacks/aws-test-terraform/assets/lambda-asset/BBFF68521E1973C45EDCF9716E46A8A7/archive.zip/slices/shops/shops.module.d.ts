export declare class ShopsModule {
}
