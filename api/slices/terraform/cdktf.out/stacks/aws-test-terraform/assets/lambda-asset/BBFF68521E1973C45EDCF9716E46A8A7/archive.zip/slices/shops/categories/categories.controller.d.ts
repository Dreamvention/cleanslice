export declare class CategoriesController {
    getCategories(): Promise<string>;
}
