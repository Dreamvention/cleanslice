import { Construct } from 'constructs';
import { IamRole } from '@cdktf/provider-aws/lib/iam-role';
export declare class IamLambda {
    static init(scope: Construct): {
        iamForLambda: IamRole;
    };
}
