import { IUserData } from '../../domain/entities';
import DB, { Prisma } from '@prisma/client';
export type IUserResponse = DB.User;
export type IUserCreateRequest = Prisma.XOR<Prisma.UserCreateInput, Prisma.UserUncheckedCreateInput>;
export type IUserUpdateRequest = Prisma.XOR<Prisma.UserUpdateInput, Prisma.UserUncheckedUpdateInput>;
export declare class UserMapper {
    toData(data: IUserResponse): IUserData;
    toCreate(data: IUserData): IUserCreateRequest;
    toUpdate(data: IUserData): IUserUpdateRequest;
}
