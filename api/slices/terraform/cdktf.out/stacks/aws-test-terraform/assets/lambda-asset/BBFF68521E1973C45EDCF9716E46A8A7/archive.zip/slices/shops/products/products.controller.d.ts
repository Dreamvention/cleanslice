export declare class ProductsController {
    getProducts(): Promise<string>;
}
