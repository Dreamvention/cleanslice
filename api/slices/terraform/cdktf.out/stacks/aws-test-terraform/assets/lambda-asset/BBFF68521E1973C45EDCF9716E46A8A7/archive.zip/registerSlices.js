"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var SlicesModule_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.SlicesModule = void 0;
const common_1 = require("@nestjs/common");
const fs = require("fs");
let SlicesModule = SlicesModule_1 = class SlicesModule {
    static async registerAsync() {
        const slices = fs.readdirSync('./slices');
        const result = [];
        for (const slice of slices) {
            const className = `${slice.charAt(0).toUpperCase() + slice.slice(1)}Module`;
            const module = await Promise.resolve(`${`./slices/${slice}/${slice}.module`}`).then(s => require(s));
            result.push(module[className]);
        }
        return {
            module: SlicesModule_1,
            imports: result,
            exports: result,
        };
    }
};
exports.SlicesModule = SlicesModule;
exports.SlicesModule = SlicesModule = SlicesModule_1 = __decorate([
    (0, common_1.Module)({})
], SlicesModule);
//# sourceMappingURL=registerSlices.js.map